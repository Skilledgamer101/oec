Competitior Names: Mansoor Lunawadi, Ronav Roy Chowdhury, Andrew Chen, Daniel Oliveira
Team Name: Egypt
Project Title: Scribble.ai

To compile and run the project:

1. Sign up for a Google Cloud Account
2. Run the main.py program in the Google Cloud Shell
3. Enter the letters which you want to practice writing
4. Upload handwriting on website
5. Your results will be shown immediately
6. The more consecutive correct results you get, the more awards you can achieve!
